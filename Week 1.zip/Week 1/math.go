package main

import "fmt"

func main() {
	a:= 10;
	b:= 20;

	//addition
	var c = a + b;
	fmt.Println("Addition: ");
	fmt.Println(c);

	//subtraction
	var d = b - a;
	fmt.Println("Subtraction:")
	fmt.Println(d);

}